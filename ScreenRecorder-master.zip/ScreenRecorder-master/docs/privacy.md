Privacy Policy
===

This simple Privacy Policy explains what permissions this application needed in runtime.

### Local storage ###
This application need save the MP4 file, which captured screen, into  your storage device like SD card.

### Audio Recording ###
This application may record audio and encode it into the MP4 file what you wanted.

